<?if( $sg == 'banner' ):?>
<div style="width:137px;text-align:center;margin:0 auto;">
<br />
</div>  
<?else:?>
 	<?php echo $mainframe->getCfg('sitename') ;?>, Powered by <a href="http://joomla.org/" class="sgfooter" target="_blank">Joomla!</a> and designed by SiteGround <a href="http://www.siteground.com/" target="_blank" class="sgfooter">web hosting</a>
 <?endif;?>